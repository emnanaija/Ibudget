import { Component } from '@angular/core';

@Component({
  selector: 'app-savings',
  imports: [],
  templateUrl: './savings.component.html',
  styleUrl: './savings.component.css'
})
export class SavingsComponent {

}
