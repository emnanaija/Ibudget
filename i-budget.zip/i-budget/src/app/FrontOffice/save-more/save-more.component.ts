import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-save-more',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './save-more.component.html',
  styleUrls: ['./save-more.component.css']
})
export class SaveMoreComponent {
  // Component logic here
}