export interface feteRecommendation {
    fete: string;
    budget: any; // Ajuste en fonction de la structure réelle
    cadeaux: any; // Ajuste en fonction de la structure réelle
  }
  