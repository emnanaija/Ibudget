
import { ExpenseCategory } from './expense-category.model';
export interface Wallet {
    solde: number;
    statut: string;
  }
export interface DepenseReccurente {
  id?: number;
  wallet: Wallet;
  categorie: ExpenseCategory;
  montant: number;
  dateDebut: string;  // ISO format: '2025-04-23'
  dateFin?: string;
  frequence: FrequenceDepense;
}
export enum FrequenceDepense {
    MENSUELLE = 'MENSUELLE',
    TRIMESTRIELLE = 'TRIMESTRIELLE',
    ANNUELLE = 'ANNUELLE'
  }
  